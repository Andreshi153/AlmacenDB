CREATE TABLE empresa (
    cif TEXT PRIMARY KEY,
    nombre TEXT,
    direccion  TEXT,
    telefono TEXT,
    correo TEXT
)