CREATE TABLE zona (
    id_zona TEXT PRIMARY KEY,
    tipo TEXT
)