CREATE TABLE producto (
    id_producto INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT,
    precio_unitario REAL,
    tipo TEXT
)