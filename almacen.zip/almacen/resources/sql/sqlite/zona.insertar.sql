INSERT INTO zona (id_zona, tipo) values('A', 'Normal');
INSERT INTO zona (id_zona, tipo) values('B', 'Normal');
INSERT INTO zona (id_zona, tipo) values('C', 'Congelados');
INSERT INTO zona (id_zona, tipo) values('D', 'Frio');
INSERT INTO zona (id_zona, tipo) values('E', 'Zona de picking');
INSERT INTO zona (id_zona, tipo) values('F', 'Normal')