INSERT INTO producto_estanteria VALUES (1, 1, 400);
INSERT INTO producto_estanteria VALUES (2, 3, 200)